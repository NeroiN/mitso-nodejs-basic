const parseEnv = () => {
    // Write your code here 
};

parseEnv();