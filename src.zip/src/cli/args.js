const parseArgs = () => {
    // Write your code here 
};

parseArgs();