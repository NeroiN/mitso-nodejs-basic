const compress = async () => {
    // Write your code here 
};

await compress();