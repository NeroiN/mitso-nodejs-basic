const performCalculations = async () => {
    // Write your code here
};

await performCalculations();