const transform = async () => {
    // Write your code here 
};

await transform();